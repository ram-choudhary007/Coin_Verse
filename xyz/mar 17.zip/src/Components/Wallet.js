import { useEffect, useState } from 'react';
import './Wallet.css'
import { useSelector } from 'react-redux';
import WalletPopup from './WalletPopup';
import AssetList from './AssetList';
import { CryptoData } from './NewCryptoData';

export default function Wallet() {
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const availToInvest = useSelector((state) => state.wallet.availableAmount);
  const investedAmount = useSelector((state) => state.wallet.investedAmount);
  const [transactionType, setTransactionType] = useState('');
  const user = useSelector((state) => state.auth?.userDetails) || null;
  const assets = useSelector((state) => state.asset.assetList);
  const [currentValue, setCurrentValue] = useState(0);

  useEffect(() => {
    if (Object.keys(assets).length > 0) {
      const calculatedValue = Object.keys(assets).reduce((acc, crypto) => {
        const quantity = assets[crypto].quantity;
        const currentPrice = CryptoData.find((data) => data.name === crypto)?.current_price;
        return acc + quantity * currentPrice;
      }, 0);
      setCurrentValue(calculatedValue);
    }
  }, [assets]);

  const totalGain = currentValue - investedAmount;

  const setPopup = (transactionType) => {
    setTransactionType(transactionType);
    setIsPopupOpen(true);
  }
  return (
    <div>
      {user ? (
        <div className='Wallet_info'>
          <div className='topWallet'>
            <div className='rowValue'>
              <p>Total portfolio value: <span className='value'>₹{availToInvest + currentValue}</span></p>
            </div>
            <div className="rowValue">
              <p>Available to Invest: <span className='value'>₹{availToInvest}</span></p>
            </div>

            <div className='walletActionBtn'>
              <button style={{ backgroundColor: "green", fontWeight: "bold" }} onClick={() => setPopup('deposit')}>deposit</button>
              <button style={{ backgroundColor: "red", fontWeight: "bold" }} onClick={() => setPopup('withdraw')}>withdraw</button>
            </div>
            {isPopupOpen && <WalletPopup setIsPopupOpen={setIsPopupOpen} transactionType={transactionType} />}
            <hr />
            <div className="rowValue" >
              <p>Invested Value: <span className='value'>₹{investedAmount}</span></p>
              <p>All time gain: <span className='value'>₹{totalGain}</span></p>
            </div>

          </div>

          <div>
            <AssetList />
          </div>

        </div>
      ) : (
        <div>
          <p style={{ margin: '100px', marginLeft: '600px', padding: '50px', color: "white" }}>Please log in to see your fund Details.</p>

        </div>
      )}
    </div>
  )
}


