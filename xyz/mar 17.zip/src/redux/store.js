import { configureStore} from "@reduxjs/toolkit";
import favSlice from "./slices/favSlice"
import authSlice from "./slices/authSlice";
import orderSlice from "./slices/orderSlice";
import walletSlice from "./slices/walletSlice";
import assetSlice from "./slices/assetSlice";

export const store = configureStore({
    reducer: {
        fav: favSlice,
        auth: authSlice,
        order: orderSlice,
        wallet: walletSlice,
        asset: assetSlice,
    }
})