import React from 'react'
import './OrderList.css'
// import { useSelector } from 'react-redux'

const OrderList = ({orders}) => {
    // const orders = useSelector((state) => state.order?.orderDetails) || null;
    if (!orders) {
        // If orders is undefined or null, return a message or handle it accordingly
        return <div style={{textAlign: "center", margin: "200px"}}>No orders available</div>;
    }
    
    return (
        <div className='OrderList'>
            <h2>Completed Orders</h2>
            {
                orders.map((item) =>
                    <div className="order_card">
                        <div>
                            <div>Order type: {item.type}</div>
                            <div>Coin: {item.name}</div>
                        </div>
                        <div>
                            <div>Amount: {item.amount}</div>
                            <div>Price: {item.price}</div>
                            <div>Quantity: {item.quantity}</div>
                        </div>
                        <div>
                            <div>
                                {item.time.toLocaleString('en-US', {
                                    day: 'numeric',
                                    month: 'short',
                                    hour: 'numeric',
                                    minute: 'numeric',
                                    hour12: true,
                                })}
                            </div>
                            <div>
                                completed
                            </div>
                        </div>
                    </div>
                )
            }

        </div>
    )
}

export default OrderList