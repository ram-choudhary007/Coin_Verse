import React from 'react';
import { useSelector } from 'react-redux';
import { CryptoData } from './NewCryptoData';

const AssetList = () => {
  const assets = useSelector((state) => state.asset.assetList);

  return (
    <div>
      <h1>Asset list</h1>
      {Object.keys(assets).map((cryptoName) => {
        const crypto = CryptoData.find((crypto) => crypto.name === cryptoName);
        const { amount, quantity } = assets[cryptoName];
        const profit = quantity * crypto.current_price - amount;

        return (
          <div key={cryptoName} className="asset_cart">
            <div>Coin: {cryptoName}</div>
            <div>Amount: {amount}</div>
            <div>Quantity: {quantity}</div>
            <div>Profit: {profit}</div>
          </div>
        );
      })}
    </div>
  );
};

export default AssetList;
