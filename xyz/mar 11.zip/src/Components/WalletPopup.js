import {useState} from 'react'
import './WalletPopup.css'
import { useDispatch } from 'react-redux'
import { deposit, withdraw } from '../redux/slices/walletSlice'

const WalletPopup = ({setIsPopupOpen, transactionType}) => {
    const [amount, setAmount] = useState('')
    const dispatch = useDispatch();

    const addAmount = () => {
        if(transactionType === 'deposit')
        {
            dispatch(deposit(amount));
        }else{
            dispatch(withdraw(amount))
        }
        
        setIsPopupOpen(false);
    }
  return (
    <div className='WalletPopup'>
        <div className="close_Btn">
            <button onClick={()=> setIsPopupOpen(false)} >close</button>
        </div>
        <div className='Tansaction'>
            <label htmlFor="#">Deposit Money</label>
            <input type="text" className='input-section' value={amount} onChange={(e) => setAmount(e.target.value)} placeholder='Enter...' />
            <br />
            <button className='transactionBtn' style={{backgroundColor: "aqua"}} onClick={addAmount}>{transactionType}</button>
        </div>
    </div>
  )
}

export default WalletPopup