import React, { useRef, useState } from 'react'
import './Popup.css'
import { buy, sell } from '../redux/slices/orderSlice'
import { useDispatch, useSelector } from 'react-redux'
import { useParams } from 'react-router-dom'
import { CryptoData } from './NewCryptoData'
import { wBuy, wSell } from '../redux/slices/walletSlice'
import { buyCrypto, sellCrypto } from '../redux/slices/assetSlice'

const Popup = ({ setPopupOpen, orderType }) => {
    const dispatch = useDispatch();
    const [amount, setAmount] = useState('');
    const availToInvest = useSelector((state) => state.wallet.availableAmount);
    // const investedAmount = useSelector((state) => state.wallet.investedAmount);
    const assets = useSelector((state) => state.asset.assetList);

    const popupRef = useRef();
    const { name } = useParams();
    const crypto = CryptoData.find((crypto) => crypto.name === name);
    
     // Check if crypto.name is present, otherwise set it to an empty object
     const selectedAsset = assets[crypto?.name] || {};

     const quantity = selectedAsset.quantity || 0;
    const investedAmount = quantity * crypto.current_price;
    
    const closePopup = () => {
        setPopupOpen(false);
    }

    const closePopupBox = (e) => {
        if (popupRef.current === e.target) {
            closePopup();
        }
    }

    const handleButtonClick = (percentage) => {
        if (orderType === 'buy') {
            const calculatedAmount = (availToInvest * percentage) / 100;
            setAmount(calculatedAmount.toFixed(2));
        }else{
            const calculatedAmount = (investedAmount * percentage) / 100;
            setAmount(calculatedAmount.toFixed(2));
        }

    };

    const handleOrder = () => {
        if (amount >= 50) {
            if (orderType === 'buy' && amount <= availToInvest) {
                dispatch(buy({
                    name: name,
                    price: crypto.current_price,
                    amount: amount,
                    quantity: amount / crypto.current_price,
                    time: new Date(),
                }));
                dispatch(wBuy(amount));
                dispatch(buyCrypto({ crypto: name, amount, quantity: amount / crypto.current_price }));
            }
            else if (orderType === 'sell' && amount <= investedAmount) {
                dispatch(sell({
                    name: name,
                    price: crypto.current_price,
                    amount: amount,
                    quantity: amount / crypto.current_price,
                    time: new Date(),
                }));
                dispatch(wSell(amount));
                dispatch(sellCrypto({ crypto: name, amount, quantity: amount / crypto.current_price }));
            }
            else {
                alert("Error: Insufficient Balance");
            }
        } else {
            alert("Error: Amount should be more than 50 Rs");
        }
        setPopupOpen(false);
    }


    return (
        <div ref={popupRef} onClick={closePopupBox} className='popup'>
            <div className="popup_box">
                <div className="closeBtn">
                    <button onClick={closePopup}>Close</button>
                </div>
                <div>
                    <h2 style={{ color: "#f5e6e6" }}>Order type: <span style={{ color: orderType === 'buy' ? "green" : "red" }}>{orderType}</span></h2>
                    {orderType === 'buy' ? (
                        <p>Available amount: {availToInvest}</p>
                    ) : (
                        <p>Invested amount: {investedAmount}</p>
                    )}
                    <label>Enter Amount: </label>
                    <input className='input-section' type="text" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder='Enter...' />
                    <div className='amount_btns'>
                        <button onClick={() => handleButtonClick(25)}>25%</button>
                        <button onClick={() => handleButtonClick(50)}>50%</button>
                        <button onClick={() => handleButtonClick(75)}>75%</button>
                        <button onClick={() => handleButtonClick(100)}>100%</button>
                    </div>
                    <button onClick={handleOrder} className='place_orderBtn' style={{ backgroundColor: orderType === 'buy' ? "green" : "red" }}>{orderType}</button>
                </div>
            </div>
        </div>
    )
}

export default Popup