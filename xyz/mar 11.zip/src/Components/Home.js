import React from 'react';
// import { CryptoDataArray } from './CryptoData';
import CryptoTable from './CryptoTable';
import { CryptoData } from './NewCryptoData'; 

export default function Home() {
  return (
    <div>
      <CryptoTable filteredArray={CryptoData} />
    </div>
  );
}
