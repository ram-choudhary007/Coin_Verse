import CryptoTable from './CryptoTable';
import { useSelector } from 'react-redux';

export default function Favourite() {
  
  const FavCoins = useSelector((state) => state.fav);
  const user = useSelector((state) => state.auth?.userDetails) || null;

  return (
    <div>
      {user ? (
        <>
          {FavCoins.length > 0 ? (
            <CryptoTable filteredArray={FavCoins} />
          ) : (
            <p style={{ margin: '100px', marginLeft: '500px', padding: '50px' }}>
              Please add coins to your favorites to see your favorite coins.
            </p>
          )}
        </>
      ) : (
        <div>
          <p style={{ margin: '100px', marginLeft: '500px', padding: '50px' }}>
            Please log in to see your favorite coins.
          </p>
        </div>
      )}
    </div>
  );
}
