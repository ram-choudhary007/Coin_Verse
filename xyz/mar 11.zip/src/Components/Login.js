import React, { useState, useEffect } from 'react';
import { auth, googleProvider } from './config/firebase';
import { signInWithPopup, signOut, onAuthStateChanged } from 'firebase/auth';
import './Login.css';

export default function Login() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    // Listen for authentication state changes
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
    });

    // Cleanup the listener on component unmount
    return () => unsubscribe();
  }, []);

  const handleGoogleSignIn = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
      // Google Sign-In successful, you can redirect or perform other actions here
      console.log("User signed in successfully");
    } catch (error) {
      console.error('Error signing in with Google:', error.message);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      // Sign-out successful, you can redirect or perform other actions here
    } catch (error) {
      console.error('Error signing out:', error.message);
    }
  };

  return (
    <div>
      <h2 className='log_head'>Login</h2>
      <div className="auth_btn">
        {user ? (
          <>
            <p>You are logged in with email: {user.email}</p>
            {user.photoURL && <img src={user.photoURL} alt="Profile" />}
            <p>User Name: {user.displayName}</p>
            <button onClick={handleSignOut}>Log Out</button>
          </>
        ) : (
          <button onClick={handleGoogleSignIn}>Log In with Google</button>
        )}
      </div>
    </div>
  );
}
