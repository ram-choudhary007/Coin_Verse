import { createSlice } from '@reduxjs/toolkit';

// Function to retrieve initial state from localStorage
const getInitialStateFromLocalStorage = () => {
  const storedState = localStorage.getItem('cryptoAssets');
  return storedState ? JSON.parse(storedState) : { assetList: {} };
};

const assetSlice = createSlice({
  name: 'crypto asset',
  initialState: getInitialStateFromLocalStorage(), // Use localStorage data as initial state
  reducers: {
    buyCrypto: (state, action) => {
      const { crypto, amount, quantity, avgPrice } = action.payload; // Destructure action.payload
      if (state.assetList[crypto]) {
        // If crypto already exists, increment quantity
        state.assetList[crypto] = {
          avgPrice: ((parseFloat(state.assetList[crypto].avgPrice) * parseFloat(state.assetList[crypto].quantity)) + (parseFloat(avgPrice) * parseFloat(quantity))) / (parseFloat(state.assetList[crypto].quantity) + parseFloat(quantity)),
          amount: Number(state.assetList[crypto].amount) + Number(amount),
          quantity: Number(state.assetList[crypto].quantity) + Number(quantity),
        };
      } else {
        // If crypto doesn't exist, create a new entry
        state.assetList[crypto] = {
          avgPrice,
          amount,
          quantity,
        };
      }
      localStorage.setItem('cryptoAssets', JSON.stringify(state)); // Update localStorage with updated state
    },

    sellCrypto: (state, action) => {
      const { crypto, amount, quantity } = action.payload;
      const updatedQuantity = Number(state.assetList[crypto].quantity) - Number(quantity);

      if (updatedQuantity > 0) {
        state.assetList[crypto] = {
          ...state.assetList[crypto], // Preserve other properties of the asset
          amount,
          quantity: updatedQuantity,
        };
      } else if (updatedQuantity < 0) {
        alert(`You don't own that much quantity`);
      } else {
        // If quantity becomes zero or negative, delete the asset
        delete state.assetList[crypto];
      }
      localStorage.setItem('cryptoAssets', JSON.stringify(state)); // Update localStorage with updated state
    },
  },
});

export const { buyCrypto, sellCrypto } = assetSlice.actions;
export default assetSlice.reducer;
