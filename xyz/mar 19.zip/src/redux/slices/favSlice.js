import { createSlice } from "@reduxjs/toolkit";

// Function to retrieve initial state from localStorage
const getInitialStateFromLocalStorage = () => {
  const storedState = localStorage.getItem("favCoins");
  return storedState ? JSON.parse(storedState) : [];
};

const favSlice = createSlice({
  name: "favoriteCoins",
  initialState: getInitialStateFromLocalStorage(), // Use localStorage data as initial state
  reducers: {
    add: (state, action) => {
      state.push(action.payload);
      localStorage.setItem("favCoins", JSON.stringify(state));
    },
    remove: (state, action) => {
      const filteredState = state.filter(item => item.id !== action.payload);
      localStorage.setItem("favCoins", JSON.stringify(filteredState));
      return filteredState;
    },
  },
});

export const { add, remove } = favSlice.actions;
export default favSlice.reducer;
