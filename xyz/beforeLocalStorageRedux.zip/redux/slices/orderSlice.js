import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    orderDetails: [],
    isOrderCompleted: false, 
  };

const orderSlice = createSlice({
  name: "Order Slice",
  initialState,
  reducers: {
    buy: (state, action) => {
        state.orderDetails.push({
            type: "buy",
            name: action.payload.name,
            id: action.payload.id,
            amount: action.payload.amount,
            price: action.payload.price,
            quantity: action.payload.quantity,
            time: action.payload.time,
            // Add other necessary fields
          });
          state.isOrderCompleted = true;
    },
    sell: (state, action) => {
      state.orderDetails.push({
        type: "sell",
        name: action.payload.name,
        id: action.payload.id,
        amount: action.payload.amount,
        price: action.payload.price,
        quantity: action.payload.quantity,
        time: action.payload.time,
        // Add other necessary fields
      });
      state.isOrderCompleted = true;
},
  },
});

export const { buy, sell } = orderSlice.actions;
export default orderSlice.reducer;
