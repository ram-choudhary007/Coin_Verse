// BaseUrl.js
const url = 'https://api.coingecko.com/api/v3';
export default url;
