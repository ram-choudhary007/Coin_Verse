import { useState } from 'react'
import './WalletPopup.css'
import { useDispatch } from 'react-redux'
import { deposit, withdraw } from '../redux/slices/walletSlice'

const WalletPopup = ({ setIsPopupOpen, transactionType }) => {
    const currentTime = new Date().toISOString();
    const [amount, setAmount] = useState('')
    const dispatch = useDispatch();

    const addAmount = () => {
        if (transactionType === 'deposit') {
          dispatch(deposit({
            amount: Number(amount),
            time: currentTime,
          }));
        } else {
          dispatch(withdraw({
            amount: Number(amount),
            time: currentTime,
          }));
        }
      
        setIsPopupOpen(false);
      }
      
    return (
        <div className='WalletPopup'>
            <div className="walletPopBox">
                <h2>{transactionType}</h2>
                <div className="close_Btn">
                    <button onClick={() => setIsPopupOpen(false)} >close</button>
                </div>
                <div className='Tansaction'>
                    <label htmlFor="#">Enter Amount: </label>
                    <input type="text" className='input-section' value={amount} onChange={(e) => setAmount(e.target.value)} placeholder='Enter...' />
                    <br />
                    <button className='transactionBtn' style={{ backgroundColor: transactionType === 'deposit' ? "#16c784" : "#ea3943" }} onClick={addAmount}>{transactionType}</button>
                </div>
            </div>
        </div>
    )
}

export default WalletPopup