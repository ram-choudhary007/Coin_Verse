import { createSlice } from "@reduxjs/toolkit";

// Function to retrieve initial state from localStorage
const getInitialStateFromLocalStorage = () => {
  const storedState = localStorage.getItem("walletState");
  return storedState ? JSON.parse(storedState) : {
    availableAmount: 500,
    investedAmount: 0,
    transactions: [],
  };
};

const walletSlice = createSlice({
  name: "Available to Invest",
  initialState: getInitialStateFromLocalStorage(), // Use localStorage data as initial state
  reducers: {
    deposit: (state, action) => {
      if (Number(action.payload.amount) >= 0) {
        state.availableAmount += Number(action.payload.amount);
        state.transactions.push({
          type: 'Deposit',
          amount: action.payload.amount,
          time: action.payload.time,
        });
        localStorage.setItem("walletState", JSON.stringify(state)); // Update localStorage with updated state
      } else {
        alert(`Amount must be positive`);
      }
    },
    withdraw: (state, action) => {
      if (Number(action.payload.amount) < 0) {
        alert(`Amount must be positive`);
      } else {
        const newAmount = state.availableAmount - Number(action.payload.amount);

        if (newAmount < 0) {
          console.error('Cannot withdraw, insufficient funds');
          alert('Cannot withdraw, insufficient funds');
        } else {
          state.availableAmount = newAmount;
          state.transactions.push({
            type: 'Withdrawal',
            amount: action.payload.amount,
            time: action.payload.time,
          });
          localStorage.setItem("walletState", JSON.stringify(state)); // Update localStorage with updated state
        }
      }
    },
    wBuy: (state, action) => {
      state.availableAmount -= Number(action.payload);
      state.investedAmount += Number(action.payload);
      localStorage.setItem("walletState", JSON.stringify(state)); // Update localStorage with updated state
    },
    wSell: (state, action) => {
      state.availableAmount += Number(action.payload);
      state.investedAmount -= Number(action.payload);
      localStorage.setItem("walletState", JSON.stringify(state)); // Update localStorage with updated state
    }
  },
});

export const { deposit, withdraw, wBuy, wSell } = walletSlice.actions;
export default walletSlice.reducer;
