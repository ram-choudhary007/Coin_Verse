import { doc, getDoc, collection } from 'firebase/firestore';
import { db } from './config/firebase';

export const handleFavState = async (index, userId, favCoin, setFavCoin) => {
  

  // Fetch user-specific data from the database
  const userDoc = doc(db, 'users', userId);
  const userData = await getDoc(userDoc);

  if (userData.exists()) {
    const userFavCoin = userData.data().favouriteCoins || [];
    setFavCoin(userFavCoin);

    // Check if the index is already in favCoin array
    const isIndexInFav = userFavCoin.includes(index);

    // If the index is in favCoin array, remove it; otherwise, add it
    const updatedFavCoin = isIndexInFav
      ? userFavCoin.filter((favIndex) => favIndex !== index)
      : [...userFavCoin, index];

    // Update favCoin in Firestore
    await collection(db, 'users').doc(userId).update({
      favouriteCoins: updatedFavCoin,
    });

    return updatedFavCoin;
  } else {
    console.error('User document does not exist');
    return [];
  }
};