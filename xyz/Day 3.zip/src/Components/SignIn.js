import React from 'react'
import { useSelector } from 'react-redux';



function SignIn() {
    const items = useSelector((state) => state);
    console.log("Items", items);
  return (
     <div>welcome, {items.user ? items.user.name : "Guest"}</div>
  )
}

export default SignIn