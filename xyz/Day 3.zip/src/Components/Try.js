import React, { useState, useEffect, useCallback } from 'react';
import { CryptoDataArray } from './CryptoData';
import { db, auth } from './config/firebase';
// import yellowStar from './Images/yellow star.png';
import { collection, doc, getDoc } from 'firebase/firestore';
import CryptoTable from './CryptoTable';

export default function Favourite() {
  const [favCoin, setFavCoin] = useState([]);

  const fetchUserData = useCallback(async (userId) => {
    // Fetch user-specific data from the database
    const userDoc = doc(collection(db, 'users'), userId);
    const userData = await getDoc(userDoc);
    setFavCoin(userData.data().favouriteCoins);
    console.log(favCoin);
  }, [favCoin, setFavCoin]);

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((authUser) => {
      if (authUser) {
        fetchUserData(authUser.uid);
      }
    });

    return () => {
      unsubscribe();
    };
  }, [fetchUserData]); // Include fetchUserData in the dependency array

  const favoriteCoins = favCoin.map(index => CryptoDataArray[index]);

  return (
    <div>
      <CryptoTable filteredArray={favoriteCoins} />
    </div>
  );
}
