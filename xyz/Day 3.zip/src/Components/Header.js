import React, { useState, useEffect } from 'react';
import './Header.css';
import Logo from '../Components/Images/logo.png';
import Search_icon from '../Components/Images/search-icon.png';
import { Link } from 'react-router-dom';
import { auth, googleProvider } from './config/firebase';
import { signInWithPopup, signOut, onAuthStateChanged } from 'firebase/auth';

export default function Header() {
  const [isSearchVisible, setIsSearchVisible] = useState(false);
  const [user, setUser] = useState(null);
  const [showLogoutButton, setShowLogoutButton] = useState(false);

  useEffect(() => {
    // Listen for authentication state changes
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
    });

    // Cleanup the listener on component unmount
    return () => unsubscribe();
  }, []);

  const toggleSearch = () => {
    setIsSearchVisible(!isSearchVisible);
  };

  const handleGoogleSignIn = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
      console.log("User log in successfully");
    } catch (error) {
      console.error('Error signing in with Google:', error.message);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      console.log("User log out successfully");
    } catch (error) {
      console.error('Error signing out:', error.message);
    }
  };

  const toggleLogoutButton = () => {
    setShowLogoutButton(!showLogoutButton);
  };

  

  return (
    <div className="header">
      <ul>
        <li className='logo_name'>
          <Link to="/">
            <div className='logo_container'>
              <img className='logo' src={Logo} alt="Crypto Verse Logo" />
              <h2>Crypto Verse</h2>
            </div>
          </Link>
        </li>
        <li>
          <Link to="/favourite">Favourite</Link>
        </li>
        {/* <li>
          <Link to="/cryptocurrencies">Cryptocurrencies</Link>
        </li> */}
        <li><Link to="/portfolio">Portfolio</Link></li>
        <li>
          <button className='search_btn' onClick={toggleSearch}>
            <img className='search_icon' src={Search_icon} alt="Search_icon" />
          </button>
          {isSearchVisible && (
            <input className='search' type="text" placeholder='Search...' />
          )}
        </li>
        <li>
          {user ? (
            <>
              <button
                className='userProfileBtn'
                onClick={toggleLogoutButton}
              >
                <img className='userProfilePhoto' src={user.photoURL} alt="Profile" />
              </button>

              {showLogoutButton && (
                <button className='LogOutBtn' onClick={handleSignOut}>Logout</button>
              )}
            </>
          ) : (
            <button className='LogInBtn' onClick={handleGoogleSignIn}>Login with Google</button>
          )}
        </li>
      </ul>
    </div>
  );
}
