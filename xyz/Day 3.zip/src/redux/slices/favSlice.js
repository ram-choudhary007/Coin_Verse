import { createSlice } from "@reduxjs/toolkit";

const favSlice = createSlice({
    name : "Favourite Coins",
    initialState: [],
    reducers:{
        handleFavState: (state, action) => {
            state.push(action.payload);
        }
    }
})

export const {handleFavState} = favSlice.actions;
export default favSlice.reducer;