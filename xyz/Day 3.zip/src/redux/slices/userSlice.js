import { createSlice } from "@reduxjs/toolkit";
import { auth } from "../../Components/config/firebase";

const userSlice = createSlice({
  name: "User",
  initialState: { user: null },
  reducers: {
    logout: (state) => {
      state.user = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase("firebase/auth/USER_CHANGED", (state, action) => {
        state.user = action.payload;
      });
  },
});

export const { logout } = userSlice.actions;

export default userSlice.reducer;