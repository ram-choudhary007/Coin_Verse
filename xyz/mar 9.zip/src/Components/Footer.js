import React from 'react'
import './Header.css';

export const Footer = () => {
  return (
    <footer className="footer">
    <div className="container">
      <div className="row">
        <div className="col-md-6">
          <h5>About Us</h5>
        </div>
        <div className="col-md-6">
          <h5>Contact</h5>
          <p>Email: fake@gmail.com</p>
          <p>Phone: 7357-456-789</p>
        </div>
      </div>
    </div>
    <p>© 2024 CryptoVerse. All rights reserved</p>
  </footer>
  )
}