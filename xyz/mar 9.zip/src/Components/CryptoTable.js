import React from 'react';
import star from './assets/star.png';
import yStar from './assets/yellow star.png'
import { Link } from 'react-router-dom';
import './CryptoTable.css';
import { useDispatch, useSelector } from 'react-redux';
import { add, remove } from '../redux/slices/favSlice'; // Import remove action

const CryptoTable = ({ filteredArray }) => {
  const dispatch = useDispatch();
  const FavC = useSelector((state) => state.fav);

  const addToFav = (crypto) => {
    // Dispatch an add action
    dispatch(add(crypto));
  }

  const removeFromFav = (id) => {
    // Dispatch a remove action
    dispatch(remove(id));
  }

  return (
    <div className="crypto-table-container">
      <div className="table-header">
        <div></div>
        <div>Rank#</div>
        <div>Coin Name</div>
        <div>Price</div>
        <div>Market Cap</div>
        <div>1d %</div>
        {/* <div>7d %</div> */}
        <div>Volume(24h)</div>
        <div>Circulating Supply</div>
      </div>
      <div className="table-rows">
        {filteredArray.map((crypto, index) => (
          <div key={index} className="table-row">
            <div>
              <button className='favBtn' onClick={() => {
                FavC.includes(crypto) ? removeFromFav(crypto.id) : addToFav(crypto)
              }}>
                <img className="star" src={FavC.includes(crypto) ? yStar : star} alt="star" />
              </button>
            </div>
            <div>{crypto.market_cap_rank}</div>
            {/* <div>{index + 1}</div> */}
            <div><Link to={`/${crypto.name}`}>{crypto.name}</Link></div>
            <div>₹{crypto.current_price}</div>
            {/* <div>${crypto.inst_price_usd}</div> */}
            <div>₹{(crypto.market_cap/1000000000).toFixed(2)}B</div>
            {/* <div>${crypto.inst_market_cap_plain}</div> */}
            <div style={{ color: parseFloat(crypto.price_change_percentage_24h) > 0 ? 'green' : 'red' }}>
              {/* {crypto.change_percent_1d} */}
              {crypto.price_change_percentage_24h.toFixed(2)}%
            </div>
            {/* <div style={{ color: parseFloat(crypto.change_percent_7d) > 0 ? 'green' : 'red' }}>
              {crypto.change_percent_7d}
            </div> */}
            <div>₹{(crypto.total_volume/1000000000).toFixed(2)}B</div>
            {/* <div>₹{crypto.volume_24h_usd_plain}</div> */}
            <div>
              {((crypto.circulating_supply)/1000000000).toFixed(2)}B {crypto.symbol}
              {/* {crypto.circulating_supply} {crypto.currency_symbol} */}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CryptoTable;
