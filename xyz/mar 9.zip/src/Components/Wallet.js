import './Wallet.css'
import { useSelector } from 'react-redux';

export default function Wallet() {

  const user = useSelector((state) => state.auth?.userDetails) || null;
  return (
    <div>
      {user ? (
        <div className='Wallet_info'>
          <div className='topWallet'>
            <div className='rowValue'>
              <p>Total portfolio value: <span className='value'>₹4500</span></p>
              </div>
              <div className="rowValue">
              <p>Available to Invest: <span className='value'>₹500</span></p>
            </div>

            <div className='walletActionBtn'>
              <button style={{backgroundColor: "green", fontWeight: "bold"}}>deposit</button>
              <button style={{backgroundColor: "red", fontWeight: "bold"}}>withdraw</button>
            </div>
              <hr />
            <div className="rowValue" >
              <p>Invested Value: <span className='value'>₹500</span></p>
              <p>All time gain: <span className='value'>₹3500</span></p>
            </div>
            
          </div>

          <div>
            <h1>Asset list</h1>
          </div>

        </div>
      ) : (
        <div>
          <p style={{ margin: '100px', marginLeft: '500px', padding: '50px' }}>Please log in to see your fund Details.</p>

        </div>
      )}
    </div>
  )
}


