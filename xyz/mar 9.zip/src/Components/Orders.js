import React from 'react'

export const Orders = () => {
  return (
    <div>Orders</div>
  )
}
