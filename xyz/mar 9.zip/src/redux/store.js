import { configureStore} from "@reduxjs/toolkit";
import favSlice from "./slices/favSlice"
import authSlice from "./slices/authSlice";

export const store = configureStore({
    reducer: {
        fav: favSlice,
        auth : authSlice,
    }
})