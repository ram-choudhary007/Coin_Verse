import { createSlice } from "@reduxjs/toolkit";

// Function to retrieve initial state from localStorage
const getInitialStateFromLocalStorage = () => {
  const storedState = localStorage.getItem("Orders");
  return storedState ? JSON.parse(storedState) : {
    orderDetails: [],
    isOrderCompleted: false,
  };
};

const orderSlice = createSlice({
  name: "Order Slice",
  initialState: getInitialStateFromLocalStorage(), // Use localStorage data as initial state
  reducers: {
    buy: (state, action) => {
      state.orderDetails.push({
        type: "buy",
        name: action.payload.name,
        id: action.payload.id,
        amount: action.payload.amount,
        price: action.payload.price,
        quantity: action.payload.quantity,
        time: action.payload.time,
        // Add other necessary fields
      });
      state.isOrderCompleted = true;
      localStorage.setItem("Orders", JSON.stringify(state)); // Update localStorage with updated state
    },
    sell: (state, action) => {
      state.orderDetails.push({
        type: "sell",
        name: action.payload.name,
        id: action.payload.id,
        amount: action.payload.amount,
        price: action.payload.price,
        quantity: action.payload.quantity,
        time: action.payload.time,
        // Add other necessary fields
      });
      state.isOrderCompleted = true;
      localStorage.setItem("Orders", JSON.stringify(state)); // Update localStorage with updated state
    },
  },
});

export const { buy, sell } = orderSlice.actions;
export default orderSlice.reducer;
