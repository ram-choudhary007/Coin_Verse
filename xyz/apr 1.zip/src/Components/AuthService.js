/* // AuthService.js
import { auth, googleProvider } from './config/firebase';
import { signInWithPopup, signOut, onAuthStateChanged } from 'firebase/auth';

class AuthService {
  // Sign in with Google
  static signInWithGoogle() {
    return signInWithPopup(auth, googleProvider);
  }

  // Sign out
  static signOut() {
    return signOut(auth);
  }

  // Get current user
  
}

export default AuthService;
 */