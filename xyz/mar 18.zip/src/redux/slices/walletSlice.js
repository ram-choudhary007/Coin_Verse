import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  availableAmount: 500,
  investedAmount: 0,
};

const walletSlice = createSlice({
  name: "Available to Invest",
  initialState,
  reducers: {
    deposit: (state, action) => {
      // return state + Number(action.payload);
      if (Number(action.payload) >= 0) {
        state.availableAmount += Number(action.payload);
      } else {
        alert(`Amount must be positive`);
      }
    },
    withdraw: (state, action) => {
      if (Number(action.payload) < 0) {
        alert(`Amount must be positive`);
      } else {
        const newAmount = state.availableAmount - Number(action.payload);

        if (newAmount < 0) {
          console.error('Cannot withdraw, insufficient funds');
          alert('Cannot withdraw, insufficient funds');
        } else {
          state.availableAmount = newAmount;
        }
      }


    },
    wBuy: (state, action) => {
      state.availableAmount -= Number(action.payload);
      state.investedAmount += Number(action.payload);
    },
    wSell: (state, action) => {
      state.availableAmount += Number(action.payload);
      state.investedAmount -= Number(action.payload);
    }
  },
});

export const { deposit, withdraw, wBuy, wSell } = walletSlice.actions;
export default walletSlice.reducer;
