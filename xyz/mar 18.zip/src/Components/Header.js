import './Header.css';
import Logo from '../Components/assets/logo.png';
import { Link } from 'react-router-dom';
import Search from './Search';
import Login from './Login';

export default function Header() {

  return (
    <div className="header">
      <ul>
        <li className='logo_name'>
          <Link to="/">
            <div className='logo_container'>
              <div><img className='logo' src={Logo} alt="Logo" /></div>
              <div><h2>Crypto Verse</h2></div>
            </div>
          </Link>
        </li>
        <li>
          <Link to="/favourite" >Favourite</Link>
        </li>
        <li><Link to="/orders">Orders</Link></li>
        <li><Link to="/wallet">Wallet</Link></li>
        <li>
          <Search />
        </li>
        <li>
          <Login />
        </li>
      </ul>
      <hr />
    </div>
  );
}
