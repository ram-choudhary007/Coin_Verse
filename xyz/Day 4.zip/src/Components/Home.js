import React from 'react';
import { CryptoDataArray } from './CryptoData';
import CryptoTable from './CryptoTable';

export default function Home() {
  return (
    <div>
      <CryptoTable filteredArray={CryptoDataArray} />
    </div>
  );
}
