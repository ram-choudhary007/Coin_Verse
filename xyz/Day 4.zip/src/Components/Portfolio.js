import React from 'react'
import { useSelector } from 'react-redux';

export default function Portfolio() {
  
  const user = useSelector((state) => state.auth?.userDetails?.userData) || null;
  return (
    <div>
    {user ? (
      <>
      <div>Portfolio</div>
      </>
    ) : (
      <div>
      <p style={{margin: '100px', marginLeft: '500px', padding: '50px'}}>Please log in to see your portfolio.</p>
    
      </div>
    )}
  </div>
  )
}


