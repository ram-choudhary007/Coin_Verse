import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { CryptoDataArray } from './CryptoData';
import axios from 'axios';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';
import { Line } from 'react-chartjs-2';

ChartJS.register(
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Legend
);

// ... (previous imports)

export default function Chart() {
    const [chartData, setChartData] = useState([]);
    const [days, setDays] = useState(1); // Initialize with the default value
    const { name } = useParams();
    const crypto = CryptoDataArray.find((crypto) => crypto.name === name);

    const fetchChartData = async () => {
        const options = {
            method: 'GET',
            url: 'https://coinranking1.p.rapidapi.com/coin/Qwsogvtv82FCd/history',
            params: {
                referenceCurrencyUuid: 'yhjMzLPhuIDl',
                timePeriod: `${days}h`, // Update the time period based on the selected days
            },
            headers: {
                'X-RapidAPI-Key': 'f4c7cfa9a8mshaa2d914a58d4c42p177238jsn28c649358d77',
                'X-RapidAPI-Host': 'coinranking1.p.rapidapi.com'
            }
        };

        try {
            const response = await axios.request(options);
            const { history } = response.data.data;
            setChartData(history);
            // console.log(history);
        } catch (error) {
            console.error('Error fetching chart data:', error);
        }
    };

    useEffect(() => {
        fetchChartData();
    }, [days, fetchChartData]); // Fetch data whenever 'days' state changes

    const myData = {
        labels: chartData.map((value) => {
            const date = new Date(value.timestamp);
            const time = date.toLocaleTimeString();
            return time;
        }),
        datasets: [
            {
                label: 'Price',
                data: chartData.map((value) => value.price),
                borderColor: 'rgba(75, 192, 192, 1)',
                fill: false,
            },
        ],
    };

    return (
        <div>
            <div>
                <Line data={myData} options={{
                    elements: {
                        point: {
                            radius: 1,
                        }
                    }
                }} style={{ marginTop: "5rem", width: "60rem" }} />

                <div className='btn' style={{ marginTop: "30px" }}>
                    <button onClick={() => setDays(1)}>24 hours</button>
                    <button onClick={() => setDays(30)}>1 Month</button>
                    <button onClick={() => setDays(365)}>1 Year</button>
                </div>
            </div>
        </div>
    );
}
