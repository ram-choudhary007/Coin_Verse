import React, { useState } from 'react';
import './Header.css';
import Logo from '../Components/assets/logo.png';
import Search_icon from '../Components/assets/search-icon.png';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { auth, googleProvider } from './config/firebase';
import { signInWithPopup, signOut } from 'firebase/auth';

export default function Header() {
  const user = useSelector((state) => state.auth?.userDetails?.userData) || null;
  const [isSearchVisible, setIsSearchVisible] = useState(false);
  const [showLogoutButton, setShowLogoutButton] = useState(false);

  const toggleSearch = () => {
    setIsSearchVisible((prev) => !prev);
  };

  const handleGoogleSignIn = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
      setShowLogoutButton((prev) => !prev);
      console.log("User logged in successfully");
    } catch (error) {
      console.error('Error signing in with Google:', error.message);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      console.log("User logged out successfully");
    } catch (error) {
      console.error('Error signing out:', error.message);
    }
  };

  const toggleLogoutButton = () => {
    setShowLogoutButton((prev) => !prev);
  };

  return (
    <div className="header">
      <ul>
        <li className='logo_name'>
          <Link to="/">
            <div className='logo_container'>
              <img className='logo' src={Logo} alt="Crypto Verse Logo" />
              <h2>Crypto Verse</h2>
            </div>
          </Link>
        </li>
        <li>
          <Link to="/favourite">Favourite</Link>
        </li>
        <li><Link to="/portfolio">Portfolio</Link></li>
        <li>
          <button className='search_btn' onClick={toggleSearch}>
            <img className='search_icon' src={Search_icon} alt="Search_icon" />
          </button>
          {isSearchVisible && (
            <input className='search' type="text" placeholder='Search...' />
          )}
        </li>
        <li>
          {user ? (
            <>
              <button
                className='userProfileBtn'
                onClick={toggleLogoutButton}
              >
                <img className='userProfilePhoto' src={user.photoURL} alt="Profile" />
              </button>

              {showLogoutButton && (
                <button className='LogOutBtn' onClick={handleSignOut}>Logout</button>
              )}
            </>
          ) : (
            <button className='LogInBtn' onClick={handleGoogleSignIn}>Login with Google</button>
          )}
        </li>
      </ul>
    </div>
  );
}
