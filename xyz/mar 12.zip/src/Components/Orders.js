import React from 'react'
import OrderList from './OrderList'
import { useSelector } from 'react-redux';

export const Orders = () => {
  
  const orders = useSelector((state) => state.order?.orderDetails) || null;
  return (
    <div>
      <OrderList orders={orders} />
    </div>
  )
}
