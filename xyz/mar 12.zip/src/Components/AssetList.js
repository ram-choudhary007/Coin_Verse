import React from 'react';
import { useSelector } from 'react-redux';
import { CryptoData } from './NewCryptoData';

const AssetList = () => {
  const assets = useSelector((state) => state.asset.assetList);

  if (!assets || Object.keys(assets).length === 0) {
    return (
      <div style={{ textAlign: 'center', margin: '200px', color: 'white' }}>
        You do not own any assets.
      </div>
    );
  }

  return (
    <div>
      <h1 style={{color:"white"}}>Asset list</h1>
      {Object.keys(assets).map((cryptoName) => {
        const crypto = CryptoData.find((crypto) => crypto.name === cryptoName);
        const { amount, quantity } = assets[cryptoName];
        const profit = quantity * crypto.current_price - amount;

        return (
          <div key={cryptoName} className="asset_cart">
            <div>Coin: {cryptoName}</div>
            <div>Amount: {amount}</div>
            <div>Quantity: {quantity}</div>
            <div>Profit: {profit}</div>
          </div>
        );
      })}
    </div>
  );
};

export default AssetList;
