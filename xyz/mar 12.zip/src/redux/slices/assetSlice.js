// cryptoSlice.js
import { createSlice } from '@reduxjs/toolkit';

const assetSlice = createSlice({
  name: 'crypto asset',
  initialState: {
    assetList: {},
  },
  reducers: {
    buyCrypto: (state, action) => {
      const { crypto, amount, quantity } = action.payload; // Destructure action.payload
      if (state.assetList[crypto]) {
        // If crypto already exists, increment quantity
        state.assetList[crypto] = {
          amount: Number(state.assetList[crypto].amount) + Number(amount),
          quantity: state.assetList[crypto].quantity + quantity,
        };
      } else {
        // If crypto doesn't exist, create a new entry
        state.assetList[crypto] = {
          amount,
          quantity,
        };
      }
    },
    
    sellCrypto: (state, action) => {
      const { crypto, amount, quantity } = action.payload;
      const updatedQuantity = state.assetList[crypto].quantity - quantity;

       if (updatedQuantity > 0) {
        state.assetList[crypto] = {
          amount,
          quantity: updatedQuantity,
        };
      }
      else if(updatedQuantity < 0){
        alert(`you don't own that much quantity`)
      } else {
        // If quantity becomes zero or negative, delete the asset
        delete state.assetList[crypto];
      };
    },
  },
});

export const { buyCrypto, sellCrypto } = assetSlice.actions;
export default assetSlice.reducer;
