// CryptoDetails.js

import React from 'react';
import { useParams } from 'react-router-dom';
import './CryptoDetails.css'; // Import your CSS file

import { CryptoDataArray } from './CryptoData';
import Chart from './Chart';

export default function CryptoDetails() {
  const { name } = useParams();
  const crypto = CryptoDataArray.find((crypto) => crypto.name === name);

  if (!crypto) {
    return <div className="crypto-details-container">Crypto not found</div>;
  }

 

  return (
    <div className="crypto-details-container">
      <h2 className='crypto_heading'><img style={{height: '20px'}} src={crypto.logo_url} alt="" /> {crypto.name} <p style={{ color: '#616e85' }}>{crypto.currency_symbol}</p></h2>
      <div className="crypto-details-info">
        <div className="left">
          <p className='key_pair'>Price: <span className='key_value'>${crypto.inst_price_usd}</span> </p>
          <p className='key_pair'>1d %: <span className='key_value'>{crypto.change_percent_1d}</span></p>
          <p className='key_pair'>Volume (24h): <span className='key_value'>${(crypto.volume_24h_usd_plain)}</span></p>
        </div>
        <div className="right">
          <p className='key_pair'>Market Cap: <span className='key_value'>${crypto.inst_market_cap_plain}</span></p>
          <p className='key_pair'>7d %: <span className='key_value'>{crypto.change_percent_7d}</span></p>
          <p className='key_pair'>
            Circulating Supply: <span className='key_value'>{crypto.circulating_supply} {crypto.currency_symbol}</span>
          </p>
        </div>
      </div>
        <div className="chart_info">
          <Chart />
        </div>
    </div>
  );
}
