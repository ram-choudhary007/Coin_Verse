import React, { useState, useEffect } from 'react';
import { CryptoDataArray } from './CryptoData';
import { db, auth } from './config/firebase'; // Assuming auth is your Firebase Authentication module
import './CrptoList.css';
import yellowStar from './Images/yellow star.png';
import { Link } from 'react-router-dom';
import { collection, doc, getDoc } from 'firebase/firestore';

export default function Favourite() {
  const [favCoin, setFavCoin] = useState([]);

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((authUser) => {
      // Fetch data or perform actions related to the user here
      if (authUser) {
        fetchUserData(authUser.uid);
      }
    });

    return () => {
      // Unsubscribe when the component unmounts
      unsubscribe();
    };
  }, []); // Ensure this effect runs only once on mount

  const fetchUserData = async (userId) => {
    // Fetch user-specific data from the database
    const userDoc = doc(collection(db, 'users'), userId);
    const userData = await getDoc(userDoc);
    setFavCoin(userData.data().favouriteCoins); 
  };

  const favoriteCoins = favCoin.map(index => CryptoDataArray[index]);

  const removeFavourite = (index) => {
    const updatedFavCoin = favCoin.filter((_, i) => i !== index);
    setFavCoin(updatedFavCoin);
  };

  return (
    <div className="table-container">
      <h1 style={{ textAlign: 'center' }}>Favourite Coin</h1>
      <table>
        <thead className='table-head'>
          <tr>
            <th></th>
            <th>#</th>
            <th>Crypto Name</th>
            <th>Price</th>
            <th>Market Cap</th>
            <th>1d %</th>
            <th>7d %</th>
            <th>Volume(24h)</th>
            <th>Circulating Supply</th>
          </tr>
        </thead>
        <tbody className='table-body'>
          {favoriteCoins.map((crypto, index) => (
            <tr key={index}>
              <td><button className='yStarBtn' onClick={() => removeFavourite(index)}><img className='star' src={yellowStar} alt="star" /></button></td>
              <td>{index + 1}</td>
              <td><Link to={`/${crypto.name}`}>{crypto.name}</Link></td>
              <td>${crypto.inst_price_usd}</td>
              <td>${crypto.inst_market_cap_plain}</td>
              <td style={{ color: "#3fc932" }}>{crypto.change_percent_1d}</td>
              <td className={crypto.change_percent_7d > 0 ? 'price-green' : 'price-red'}>
                {crypto.change_percent_7d}
              </td>
              <td>${crypto.volume_24h_usd_plain}</td>
              <td>{crypto.circulating_supply} {crypto.currency_symbol}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
