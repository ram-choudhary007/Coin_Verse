/* import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './CrptoList.css';
import star from './Images/star.png'

export default function CryptoList() {
  const [cryptoData, setCryptoData] = useState([]);

  const fetchData = async () => {
    const res = {
      method: 'GET',
      // url: 'https://investing-cryptocurrency-markets.p.rapidapi.com/coins/list',
      headers: {
        'X-RapidAPI-Key': 'f4c7cfa9a8mshaa2d914a58d4c42p177238jsn28c649358d77',
        'X-RapidAPI-Host': 'investing-cryptocurrency-markets.p.rapidapi.com'
      }
    };

    try {
      const response = await axios.request(res);
      console.log(response.data.data[0].screen_data.crypto_data);
      if (response.data && Array.isArray(response.data.data) && response.data.data.length > 0 && response.data.data[0].screen_data) {
        setCryptoData(response.data.data[0].screen_data.crypto_data);
      } else {
        console.warn('Unexpected API response structure:', response.data);
      }
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    // Fetch data initially
    fetchData();

    // Fetch data every hour
    const intervalId = setInterval(() => {
      fetchData();
    }, 3600000); // 1 hour in milliseconds

    // Clear the interval when the component is unmounted
    return () => clearInterval(intervalId);
  }, []); // empty dependency array means this effect runs once after the initial render

  return (
    <div className="table-container">
      <h1 style={{ textAlign: 'center' }}>Crypto Data</h1>
      <table>
        <thead className='table-head'>
          <tr>
            <th></th>
            <th>#</th>
            <th>Crypto Name</th>
            <th>Price</th>
            <th>Market Cap</th>
            <th>1d %</th>
            <th>7d %</th>
            <th>Volume(24h)</th>
            <th>Circulating Supply</th>
          </tr>
        </thead>
        <tbody className='table-body'>
          {cryptoData.map((crypto, index) => (
            <tr key={index}>
              <td> <img className='star' src={star} alt="star" /></td>
              <td>{index + 1}</td>
              <td>{crypto.name}</td>
              <td>${crypto.inst_price_usd}</td>
              <td>${crypto.inst_market_cap_plain}</td>
              <td style={{color: "#3fc932"}}>
                {crypto.change_percent_1d}
              </td>
              <td className={crypto.change_percent_7d > 0 ? 'price-green' : 'price-red'}>
                {crypto.change_percent_7d}
              </td>
              <td>${crypto.volume_24h_usd_plain}</td>
              <td>{crypto.circulating_supply} {crypto.currency_symbol}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
} */