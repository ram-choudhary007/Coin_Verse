import React, { useState, useEffect } from 'react';
import { db, auth } from './config/firebase';
import { collection, doc, getDoc } from 'firebase/firestore';
import { CryptoDataArray } from './CryptoData';

export default function Home() {
  const [favCoin, setFavCoin] = useState([]);

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((authUser) => {

      // Fetch data or perform actions related to the user here
      if (authUser) {
        fetchUserData(authUser.uid);
      }
    });

    return () => {
      // Unsubscribe when the component unmounts
      unsubscribe();
    };
  }, []); // Ensure this effect runs only once on mount

  const fetchUserData = async (userId) => {
    // Fetch user-specific data from the database
    const userDoc = doc(collection(db, 'users'), userId);
    const userData = await getDoc(userDoc);
    setFavCoin(userData.data().favouriteCoins); // Update state with user data
    console.log(userData.data().favouriteCoins);
  };

  const favoriteCoins = favCoin.map(index => CryptoDataArray[index]);
  console.log(favCoin);
  console.log(favoriteCoins);

  return (
    <div>
      {/* Your component content here */}
      {favoriteCoins.map((coin) => (
        <p key={coin.id}>{coin.name}</p>
      ))}
    </div>
  );
}