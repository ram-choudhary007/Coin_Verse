import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from './Components/Home';
import Cryptocurrencies from './Components/Cryptocurrencies';
import './App.css';
import Header from "./Components/Header";
import Portfolio from "./Components/Portfolio";
import Favourite from "./Components/Favourite";
import CryptoDetails from "./Components/CryptoDetails";
import Login from "./Components/Login";
import { Footer } from "./Components/Footer";

function App() {
  return (
    <BrowserRouter>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/cryptocurrencies" element={<Cryptocurrencies />} />
        <Route path="/portfolio" element={<Portfolio />} />
        <Route path="/favourite" element={<Favourite />} />
        <Route path="/:name" element={<CryptoDetails />} />
        <Route path="/login" element={<Login />} />

      </Routes>
      <Footer />
    </BrowserRouter>
  );
}

export default App;
