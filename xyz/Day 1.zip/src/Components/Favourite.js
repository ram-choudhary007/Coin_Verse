import React, { useState, useEffect, useCallback } from 'react';
import { CryptoDataArray } from './CryptoData';
import { db, auth } from './config/firebase';
import { collection, doc, getDoc } from 'firebase/firestore';
import CryptoTable from './CryptoTable';
import { Link } from 'react-router-dom';

export default function Favourite() {
  const [favCoin, setFavCoin] = useState([]);
  const [userLoggedIn, setUserLoggedIn] = useState(false);

  const fetchUserData = useCallback(async (userId) => {
    const userDoc = doc(collection(db, 'users'), userId);
    const userData = await getDoc(userDoc);
    setFavCoin(userData.data().favouriteCoins);
  }, []);

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((authUser) => {
      if (authUser) {
        setUserLoggedIn(true);
        fetchUserData(authUser.uid);
      } else {
        setUserLoggedIn(false);
        setFavCoin([]); // Reset favCoin when the user is not logged in
      }
    });

    return () => {
      unsubscribe();
    };
  }, [fetchUserData]);

  const favoriteCoins = favCoin.map(index => CryptoDataArray[index]);

  return (
    <div>
      {userLoggedIn ? (
        <CryptoTable filteredArray={favoriteCoins} />
      ) : (
        <div>
        <p style={{margin: '100px', marginLeft: '500px', padding: '50px'}}>Please log in to see your favorite coins.</p>
        <Link></Link>
        </div>
      )}
    </div>
  );
}
