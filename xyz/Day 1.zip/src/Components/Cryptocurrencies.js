import React from 'react'

export default function Cryptocurrencies() {
  return (
    <div>Cryptocurrencies</div>
  )
}
