export const handleFavState = () => {
    return ;
  };